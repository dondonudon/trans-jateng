<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class muatanBus extends Model
{
    protected $table = 'muatan_bus';
}
