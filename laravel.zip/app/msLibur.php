<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class msLibur extends Model
{
    protected $table = 'ms_libur';
}
