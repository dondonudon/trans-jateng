<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class msPenumpangBayar extends Model
{
    protected $table = 'ms_penumpang_bayar';
}
