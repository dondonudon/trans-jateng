<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class msPenumpang extends Model
{
    protected $table = 'ms_penumpang';
}
