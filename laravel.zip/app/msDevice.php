<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class msDevice extends Model
{
    protected $table = 'ms_devices';
}
