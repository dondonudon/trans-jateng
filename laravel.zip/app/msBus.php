<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class msBus extends Model
{
    protected $table = 'ms_bus';
}
