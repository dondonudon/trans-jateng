<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class masterShelter extends Model
{
    protected $table = 'master_shelter';
}
