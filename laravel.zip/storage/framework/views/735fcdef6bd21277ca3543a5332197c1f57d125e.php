<!-- General JS Scripts -->
<script src="<?php echo e(asset('vendors/general.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/stisla.js')); ?>"></script>

<!-- JS Libraies -->
<script src="<?php echo e(asset('vendors/plugin.js')); ?>"></script>

<!-- Template JS File -->
<script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>


<script>
    let btnLogout = $('#btnLogout');
    btnLogout.click(function (e) {
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url('logout')); ?>',
            method: 'post',
            success: function (response) {
                if (response === 'success') {
                    window.location.reload();
                } else {
                    console.log(response);
                    Swal.fire({
                        icon: 'warning',
                        title: 'Gagal Logout',
                        text: 'Silahkan coba lagi atau hubungi WAVE Solusi Indonesia',
                    });
                }
            },
            error: function (response) {
                console.log(response);
                Swal.fire({
                    icon: 'error',
                    title: 'System Error!',
                    text: 'Silahkan hubungi WAVE Solusi Indonesia',
                });
            }
        });
    });

    // const platform = new H.service.Platform({
    //     'apikey': 'SVQjU5j3pvx_8Ea6iBG3mjwNwt2v5wNw3h-IWyfpLUg'
    // });
    //
    // const defaultLayers = platform.createDefaultLayers();
</script><?php /**PATH /var/www/html/trans-jateng/resources/views/dashboard/_partials/footer-script.blade.php ENDPATH**/ ?>