<footer class="main-footer">
    <div class="footer-left">
        <i class="fas fa-copyright"></i> <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>

        <div class="bullet"></div>
        Developed by <a href="https://waveitsolution.com/"><?php echo e(config('app.developer')); ?></a>
    </div>
    <div class="footer-right">
        0.8.0
    </div>
</footer>
<?php /**PATH /var/www/html/trans-jateng/resources/views/dashboard/_partials/footer.blade.php ENDPATH**/ ?>