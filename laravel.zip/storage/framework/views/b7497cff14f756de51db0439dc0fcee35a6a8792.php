<?php
    $segments = \Illuminate\Support\Facades\Request::segments();
?>
<div class="section-header">

    <h1><?php echo e((isset($segments[1]) ? ucfirst(str_replace('-',' ',$segments[1])) : 'Dashboard') . (isset($segments[2]) ? ' '.ucfirst(str_replace('-',' ',$segments[2])) : '')); ?></h1>
    <div class="section-header-breadcrumb">

        <?php $__currentLoopData = $segments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="breadcrumb-item active"><?php echo e(ucfirst($segment)); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH /var/www/html/trans-jateng/resources/views/dashboard/_partials/section-header.blade.php ENDPATH**/ ?>