<?php $__env->startSection('content'); ?>
    <div class="section-body">
        <div class="row">
            <div class="col-12 col-md-6 col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Bus Report Detail</h4>
                    </div>
                    <form id="formData">
                        <input type="hidden" name="type" value="edit">
                        <input type="hidden" id="iID" name="id" value="<?php echo e($data->id); ?>">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-6">
                                    <dl class="row">
                                        <dt class="col-sm-3">Tanggal - Jam</dt>
                                        <dd class="col-sm-9"><?php echo e(date('d F Y - H:i:s',strtotime($data->created_at))); ?></dd>

                                        <dt class="col-sm-3">Petugas</dt>
                                        <dd class="col-sm-9"><?php echo e($data->name); ?></dd>

                                        <dt class="col-sm-3">Shift</dt>
                                        <dd class="col-sm-9"><?php echo e($data->shift); ?></dd>

                                        <dt class="col-sm-3">Bus</dt>
                                        <dd class="col-sm-9"><?php echo e($data->bus); ?></dd>

                                        <dt class="col-sm-3">Koridor</dt>
                                        <dd class="col-sm-9"><?php echo e($data->koridor); ?></dd>

                                        <dt class="col-sm-3">Trip</dt>
                                        <dd class="col-sm-9"><?php echo e($data->trip); ?></dd>

                                        <dt class="col-sm-3">Keterangan</dt>
                                        <dd class="col-sm-9"><?php echo e($data->keterangan); ?></dd>
                                    </dl>
                                </div>
                                <div class="col-sm-12 col-md-12 col-lg-6">
                                    <div class="form-group">
                                        <label>Lokasi</label>
                                        <div style="width: 100%; height: 300px" id="mapContainer"></div>
                                    </div>
                                    <button type="button" class="btn btn-block btn-outline-primary" id="btnMaps">
                                        <i class="fab fa-google mr-2"></i>Open in Maps
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer bg-whitesmoke">
                            <div class="row justify-content-end">
                                <div class="col-sm-12 col-lg-2 mt-2 mb-lg-0">
                                    <button type="button" class="btn btn-block btn-outline-danger" onclick="window.location = '<?php echo e(url()->previous()); ?>'">
                                        <i class="fas fa-arrow-left mr-2"></i>Kembali
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        let btnMaps = $('#btnMaps');
        let myLocation = { lat: -6.966667, lng: 110.416664 };
        let lokasi = {lat: Number('<?php echo e($data->latitude); ?>'), lng: Number('<?php echo e($data->longitude); ?>')};

        function initMap() {
            let map = new google.maps.Map(document.getElementById('mapContainer'), {
                center: myLocation,
                zoom: 12
            });

            placeMarkerAndPanTo(lokasi, map);
        }

        function placeMarkerAndPanTo(latLng, map) {
            mapMarker = new google.maps.Marker({
                position: latLng,
                map: map
            });
            map.panTo(latLng);
            mapMarkers = mapMarker;
        }
        let mapMarkers = null;

        $(document).ready(function () {
            btnMaps.click(function (e) {
                e.preventDefault();
                window.open('https://www.google.com/maps/search/?api=1&query='+lokasi.lat+','+lokasi.lng);
            });
        });
    </script>
    <?php echo $__env->make('dashboard._partials.google-maps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/trans-jateng/resources/views/dashboard/problem/bus-report/detail.blade.php ENDPATH**/ ?>