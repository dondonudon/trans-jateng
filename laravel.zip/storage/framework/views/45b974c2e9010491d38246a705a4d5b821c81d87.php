<?php
    $sidebar = \App\Http\Controllers\c_Dashboard::sidebar();
    $segGroup = request()->segment(2);
    $segMenu = request()->segment(3);
?>
<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="<?php echo e(url('/')); ?>"><?php echo e(config('app.name')); ?></a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('assets/logo/without-name/logo-1000.png')); ?>" style="width: 100%" alt="logo">
            </a>
        </div>
        <ul class="sidebar-menu">
            <li class="nav-item dropdown">
                <a href="<?php echo e(url('/')); ?>" class="nav-link"><i class="fas fa-fire"></i><span>Dashboard</span></a>
            </li>
            <?php $__currentLoopData = $sidebar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($g['group']['segment_name'] == $segGroup): ?>
                    <?php ($statGroup = 'active'); ?>
                <?php else: ?>
                    <?php ($statGroup = ''); ?>
                <?php endif; ?>
                <li class="nav-item dropdown <?php echo e($statGroup); ?>">
                    <a href="#" class="nav-link has-dropdown" data-toggle="dropdown">
                        <i class="<?php echo e($g['group']['icon']); ?>"></i>
                        <span><?php echo e($g['group']['name']); ?></span>
                    </a>
                    <ul class="dropdown-menu">
                        <?php $__currentLoopData = $g['menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($m['segment_name'] == $segMenu): ?>
                                <?php ($statMenu = 'active'); ?>
                            <?php else: ?>
                                <?php ($statMenu = ''); ?>
                            <?php endif; ?>
                            <li class="<?php echo e($statMenu); ?>">
                                <a class="nav-link" href="<?php echo e(url($m['url'])); ?>"><?php echo e($m['name']); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </aside>
</div>
<?php /**PATH /var/www/html/trans-jateng/resources/views/dashboard/_partials/sidebar.blade.php ENDPATH**/ ?>