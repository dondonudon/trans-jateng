<footer class="main-footer">
    <div class="footer-left">
        <i class="fas fa-copyright"></i> {{ date('Y') }} {{ config('app.name') }}
        <div class="bullet"></div>
        Developed by <a href="https://waveitsolution.com/">{{ config('app.developer') }}</a>
    </div>
    <div class="footer-right">
        0.8.0
    </div>
</footer>
